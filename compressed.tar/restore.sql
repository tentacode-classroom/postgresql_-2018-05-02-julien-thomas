--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.3 (Debian 11.3-1.pgdg90+1)
-- Dumped by pg_dump version 11.3 (Debian 11.3-1.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE chat;
--
-- Name: chat; Type: DATABASE; Schema: -; Owner: super_admin
--

CREATE DATABASE chat WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE chat OWNER TO super_admin;

\connect chat

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: bateau; Type: TABLE; Schema: public; Owner: super_admin
--

CREATE TABLE public.bateau (
    id integer NOT NULL,
    nom character varying(255)
);


ALTER TABLE public.bateau OWNER TO super_admin;

--
-- Name: bateau_de_croisiere; Type: TABLE; Schema: public; Owner: super_admin
--

CREATE TABLE public.bateau_de_croisiere (
    nombre_de_cabines integer NOT NULL
)
INHERITS (public.bateau);


ALTER TABLE public.bateau_de_croisiere OWNER TO super_admin;

--
-- Name: bateau_id_seq; Type: SEQUENCE; Schema: public; Owner: super_admin
--

CREATE SEQUENCE public.bateau_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bateau_id_seq OWNER TO super_admin;

--
-- Name: bateau_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: super_admin
--

ALTER SEQUENCE public.bateau_id_seq OWNED BY public.bateau.id;


--
-- Name: bateau id; Type: DEFAULT; Schema: public; Owner: super_admin
--

ALTER TABLE ONLY public.bateau ALTER COLUMN id SET DEFAULT nextval('public.bateau_id_seq'::regclass);


--
-- Name: bateau_de_croisiere id; Type: DEFAULT; Schema: public; Owner: super_admin
--

ALTER TABLE ONLY public.bateau_de_croisiere ALTER COLUMN id SET DEFAULT nextval('public.bateau_id_seq'::regclass);


--
-- Data for Name: bateau; Type: TABLE DATA; Schema: public; Owner: super_admin
--

COPY public.bateau (id, nom) FROM stdin;
\.
COPY public.bateau (id, nom) FROM '$$PATH$$/2868.dat';

--
-- Data for Name: bateau_de_croisiere; Type: TABLE DATA; Schema: public; Owner: super_admin
--

COPY public.bateau_de_croisiere (id, nom, nombre_de_cabines) FROM stdin;
\.
COPY public.bateau_de_croisiere (id, nom, nombre_de_cabines) FROM '$$PATH$$/2869.dat';

--
-- Name: bateau_id_seq; Type: SEQUENCE SET; Schema: public; Owner: super_admin
--

SELECT pg_catalog.setval('public.bateau_id_seq', 1, true);


--
-- PostgreSQL database dump complete
--

